# BodyMaster X 2.0 — Android

هذا مشروع Android حقيقي يضم نسخة BodyMaster X داخل WebView، مع حفظ التقدم محليًا عبر localStorage.

## البناء
1. افتح المجلد في Android Studio.
2. انتظر مزامنة Gradle.
3. اختر Build > Build APK(s).
4. ملف debug APK سيظهر عادةً داخل `app/build/outputs/apk/debug/`.

## المتطلبات
- Android Studio حديث.
- Android SDK 35.
- JDK 17 أو أحدث.
- اتصال أولي لتنزيل Android Gradle Plugin إن لم يكن موجودًا في الجهاز.

## ملاحظات
- التطبيق يعمل دون خادم.
- لا يحتاج حسابًا.
- البيانات تحفظ محليًا على الهاتف.
- لا توجد إعلانات أو خدمات خارجية في هذا المشروع.
- هذه النسخة ليست تشخيصًا طبيًا.
