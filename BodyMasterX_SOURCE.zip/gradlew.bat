@echo off
set DIR=%~dp0
set DIST=%USERPROFILE%\.gradle\wrapper\dists\bodymaster-gradle-8.11.1
if not exist "%DIST%\gradle-8.11.1\bin\gradle.bat" (
  echo Please run the GitHub Actions workflow or install Gradle 8.11.1.
  exit /b 1
)
call "%DIST%\gradle-8.11.1\bin\gradle.bat" %*
