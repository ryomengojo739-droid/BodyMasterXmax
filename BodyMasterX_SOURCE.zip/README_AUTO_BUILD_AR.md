# BodyMaster X — جاهز للبناء التلقائي

هذه هي النسخة النهائية المعدة للبناء عبر GitHub Actions.

## ماذا تفعل؟

GitHub سيقوم تلقائياً بتجهيز:
- Java 17
- Android SDK 35
- Build Tools 35
- Gradle 8.11.1

ثم يبني:
- `BodyMaster-X-APK` — APK تجريبي قابل للتثبيت.
- `BodyMaster-X-Release-APK` — نسخة Release غير موقعة.

## الطريقة

1. افتح GitHub وأنشئ حساباً مجانياً.
2. أنشئ Repository جديداً.
3. ارفع **محتويات هذه الحزمة** إلى Repository.
4. افتح تبويب **Actions**.
5. اختر **Build BodyMaster X APK**.
6. اضغط **Run workflow**.
7. بعد انتهاء البناء افتح صفحة التشغيل.
8. في أسفل الصفحة ستجد **Artifacts**.
9. نزّل `BodyMaster-X-APK`.
10. فك الضغط وثبّت ملف APK على هاتف Android.

## لا تحتاج

- Android Studio
- Android SDK
- Gradle
- كمبيوتر قوي

البناء يتم على GitHub.

## ملاحظة

نسخة Release الموجودة في هذه الحزمة غير موقعة. للاستخدام الشخصي استخدم APK التجريبي.
للنشر على Google Play نحتاج لاحقاً إنشاء Keystore وتوقيع Release.

## الأمان

لا تضع أي كلمات مرور أو مفاتيح توقيع داخل المستودع العام.
